from __future__ import annotations

import ast
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

WORKTREE = Path('/tmp/sv-remaining-question-01-worktree')
EVIDENCE = Path('/tmp/remaining-question-prototype-evidence')
PROTOCOL = json.loads(Path('/Users/miyauchitsubasa/Desktop/github/shadowverse-deckmaker/evals/discovery/remaining-question-01/protocol.json').read_text())
PYTHON = '/tmp/sv-system-venv/bin/python'
BASE_SRC = EVIDENCE / 'runtime/base/src'


def manifest(folder: Path) -> dict[str, str]:
    return {str(p.relative_to(folder)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(folder.rglob('*')) if p.is_file()}


def test_code_scope() -> None:
    base = (BASE_SRC / 'svdeck/discovery.py').read_text()
    variant = (WORKTREE / 'src/svdeck/discovery.py').read_text()
    addition = 'DEVELOP += ' + repr(PROTOCOL['variant_instruction']) + '\n\n'
    assert variant.count(addition) == 1
    assert variant.replace(addition, '', 1) == base
    base_tree = ast.parse(base)
    variant_tree = ast.parse(variant)
    added = variant_tree.body.pop(-2)
    assert isinstance(added, ast.AugAssign)
    assert isinstance(added.target, ast.Name) and added.target.id == 'DEVELOP'
    assert ast.dump(variant_tree) == ast.dump(base_tree)
    for original in BASE_SRC.rglob('*.py'):
        relative = original.relative_to(BASE_SRC)
        if str(relative) != 'svdeck/discovery.py':
            assert original.read_bytes() == (WORKTREE / 'src' / relative).read_bytes()
    (EVIDENCE / 'code-scope.json').write_text(json.dumps({
        'verdict': 'PASS', 'sole_code_change': 'DEVELOP += exact variant_instruction',
        'exact_instruction': PROTOCOL['variant_instruction'],
        'review_finish_develop_rules_unchanged': True,
        'validator_query_runtime_response_examples_unchanged': True,
        'all_other_python_files_unchanged': True,
    }, ensure_ascii=False, indent=2) + '\n')


def test_real_public_packets() -> None:
    source = Path(PROTOCOL['source'])
    before = manifest(source)
    assert before == PROTOCOL['source_manifest']
    (EVIDENCE / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    assert len(list(source.glob('revision-*.json'))) == 2
    assert len(list(source.glob('review-*.json'))) == 1
    assert len(list((source / 'sources').glob('*.json'))) == 26
    results = {}
    try:
        for variant, code in [('base', BASE_SRC), ('variant', WORKTREE / 'src')]:
            session = EVIDENCE / 'sessions' / variant
            shutil.copytree(source, session)
            assert manifest(session) == before
            first_source = sorted((session / 'sources').glob('*.json'))[0].stem
            env = dict(os.environ, PYTHONPATH=str(code), PYTHONDONTWRITEBYTECODE='1')
            for stage, extra in [
                ('develop', ['--stage', 'develop', '--revision', '2']),
                ('initial', ['--stage', 'develop', '--revision', '0']),
                ('review', ['--stage', 'review', '--revision', '2']),
                ('finish', ['--stage', 'develop', '--revision', '2', '--finish-from-source', first_source]),
            ]:
                command = [PYTHON, '-m', 'svdeck.discovery', 'packet', str(session), *extra]
                result = subprocess.run(command, env=env, capture_output=True, check=False)
                (EVIDENCE / f'{variant}-{stage}.stderr.txt').write_bytes(result.stderr)
                assert result.returncode == 0, result.stderr.decode()
                with gzip.open(EVIDENCE / f'{variant}-{stage}.json.gz', 'wb') as output:
                    output.write(result.stdout)
                results[variant, stage] = json.loads(result.stdout)
            after_copy = manifest(session)
            assert all(after_copy.get(name) == value for name, value in before.items())
        for stage in ('develop', 'initial'):
            base = results['base', stage]['data']
            variant = results['variant', stage]['data']
            assert variant['instruction'] == base['instruction'] + PROTOCOL['variant_instruction']
            assert {k: v for k, v in base.items() if k != 'instruction'} == {
                k: v for k, v in variant.items() if k != 'instruction'}
        for stage in ('review', 'finish'):
            assert results['base', stage] == results['variant', stage]
        data = results['base', 'develop']['data']
        assert data['revision'] == 2
        assert len(data['sources']) == 26
        assert len(data['previous_reviews']) == 1
        assert results['base', 'review']['data']['previous_reviews'] == []
        summary = {
            'verdict': 'PASS', 'source': str(source), 'source_files': len(before),
            'formal_revisions': 2, 'latest_reviews': 1, 'sources': 26,
            'public_cli_packet_invocations': 8,
            'develop_changes': ['data.instruction', 'sha256'],
            'initial_develop_changes': ['data.instruction', 'sha256'],
            'review_byte_semantics_identical': True, 'finish_byte_semantics_identical': True,
            'non_instruction_data_identical': True,
            'context_cards_notes_proposal_history_sources_search_review_contexts_response_example_identical': True,
            'review_excludes_old_reviews': True, 'copy_original_files_preserved': True,
            'packet_hashes': {f'{variant}-{stage}': value['sha256']
                              for (variant, stage), value in results.items()},
            'no_ai_launched': True,
        }
    finally:
        after = manifest(source)
        (EVIDENCE / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
        assert after == before
    summary['original_input_unchanged'] = True
    (EVIDENCE / 'public-packet-check.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
