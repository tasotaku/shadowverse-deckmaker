# Test coverage

1. (a) The real revision input differs only by the exact fixed DEVELOP addition: public packet comparison (new temporary verification).
2. (a) Proposal, both revisions, latest review, 26 sources, card text and both notes remain equal: public packet comparison; existing discovery/history/review-context/read/source tests.
3. (b) Initial DEVELOP and revision DEVELOP have the same limited addition; REVIEW, FINISH, DEVELOP_RULES and response examples remain unchanged: temporary scope check and existing packet tests.
4. (b) Original input stays byte-identical and existing saved packets are retained: before/after manifest check.
5. (c) Invalid roles, wrong packet/quote, corrupt context/history and invalid FINISH source remain rejected: existing test_discovery, test_discovery_history, test_discovery_review_contexts and test_discovery_sources.

No AI process is launched. This verifies instruction delivery and invariants, not discovery usefulness.
