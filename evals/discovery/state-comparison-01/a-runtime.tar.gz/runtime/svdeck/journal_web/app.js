'use strict';
const app = document.querySelector('#app');
const labels = {planned:'未着手',running:'作業中',waiting:'待機',completed:'完了',interrupted:'中断',unassessed:'未判定',adopted:'採用',rejected:'却下',deferred:'保留',mixed:'一部確認・課題あり',pass:'PASS',fail:'FAIL',method:'探索手法',infrastructure:'基盤検証'};
let items=[], token='', root='', store='', filter='all', search='', editing=null, listScroll=0, refreshTimer;
const esc = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const badge = (value,text) => `<span class="badge ${esc(value)}">${esc(text||labels[value]||value)}</span>`;
const date = value => value ? new Intl.DateTimeFormat('ja-JP',{timeZone:'Asia/Tokyo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(new Date(value)) : '未記録';
const duration = seconds => {const s=Math.max(0,Math.floor(seconds));return `${s>=3600?Math.floor(s/3600)+'時間 ':''}${Math.floor(s%3600/60)}分 ${s%60}秒`;};
function elapsed(item, asOf=null){
  if(!item.started_at)return {text:'未記録',seconds:null};
  if(!item.ended_at&&!['running','waiting'].includes(item.status))return {text:'未記録（終了時刻なし）',seconds:null};
  const seconds=((item.ended_at?new Date(item.ended_at):asOf?new Date(asOf):new Date())-new Date(item.started_at))/1000;
  return {text:duration(seconds)+(item.ended_at?'':asOf?'（保存時点）':'（継続）'),seconds};
}
const activeStages = r => r.stages.filter(s=>['running','waiting'].includes(s.status));
const current = r => {const stages=activeStages(r);return stages.length?stages.map(s=>s.title+' · '+labels[s.status]).join(' / '):r.status==='completed'?'試行終了':r.status==='interrupted'?'中断':r.stages.filter(s=>s.status==='planned').map(s=>s.title+' · 未着手').join(' / ')||'工程未記録';};
async function api(path,options){const response=await fetch(path,options);const data=await response.json();if(!response.ok)throw new Error(data.error||'読み込めませんでした');return data;}
function notify(message){document.querySelector('#notice').textContent=message;setTimeout(()=>document.querySelector('#notice').textContent='',5500);}
async function load(){const data=await api('/api/experiments');items=data.items.sort((a,b)=>Number(['running','waiting'].includes(b.record.status))-Number(['running','waiting'].includes(a.record.status)));token=data.token;root=data.root;store=data.store;}
function counts(){return {active:items.filter(x=>['running','waiting'].includes(x.record.status)).length,done:items.filter(x=>x.record.status==='completed').length,pending:items.filter(x=>x.record.decision.status==='unassessed').length};}
const preview=document.querySelector('#summary-preview');
let previewTrigger=null, previewPinned=false, previewTimer, restoringPreviewFocus=false;
function summaryButton(text,label){
  // AI_NOTE: 全文は表示中の行から読み、一覧の省略とキーボード操作を両立する。
  return `<button type="button" class="summary-trigger" data-preview-label="${esc(label)}" aria-label="${esc(label)}の全文を表示" aria-haspopup="dialog" aria-controls="summary-preview" aria-expanded="false"><span class="summary">${esc(text)}</span><span class="summary-more" aria-hidden="true">全文</span></button>`;
}
function positionPreview(){
  // AI_NOTE: 表の幅や行高を変えず、狭い画面でも小窓を画面内に収める。
  if(preview.hidden||!previewTrigger)return;
  const rect=previewTrigger.getBoundingClientRect(), margin=12, gap=8;
  const width=preview.offsetWidth, viewportWidth=document.documentElement.clientWidth, viewportHeight=window.innerHeight;
  let left, top, maxHeight=Math.min(560,viewportHeight-margin*2);
  if(viewportWidth-rect.right-margin>=width+gap){left=rect.right+gap;top=rect.top;}
  else if(rect.left-margin>=width+gap){left=rect.left-width-gap;top=rect.top;}
  else{
    left=Math.max(margin,Math.min(rect.left,viewportWidth-width-margin));
    const below=viewportHeight-rect.bottom-gap-margin, above=rect.top-gap-margin;
    maxHeight=Math.min(maxHeight,Math.max(above,below));
    preview.style.maxHeight=`${maxHeight}px`;
    top=below>=above?rect.bottom+gap:rect.top-gap-preview.offsetHeight;
  }
  preview.style.maxHeight=`${maxHeight}px`;
  preview.style.left=`${Math.max(margin,left)}px`;
  preview.style.top=`${Math.max(margin,Math.min(top,viewportHeight-preview.offsetHeight-margin))}px`;
}
function openPreview(trigger,pin=false){
  // AI_NOTE: ホバーでは焦点を移さず、クリック・Enterなら固定して小窓内へ入る。
  clearTimeout(previewTimer);
  if(previewPinned&&previewTrigger!==trigger&&!pin)return;
  const same=previewTrigger===trigger;
  if(previewTrigger&&!same)previewTrigger.setAttribute('aria-expanded','false');
  previewPinned=pin||(same&&previewPinned);
  previewTrigger=trigger;
  if(!same||preview.hidden){
    document.querySelector('#preview-heading').textContent=trigger.dataset.previewLabel;
    document.querySelector('#preview-trial').textContent=trigger.closest('tr').querySelector('.trial-title').textContent;
    document.querySelector('#preview-text').textContent=trigger.querySelector('.summary').textContent;
    document.querySelector('#preview-text').scrollTop=0;
  }
  preview.hidden=false;trigger.setAttribute('aria-expanded','true');positionPreview();
  if(pin)document.querySelector('#preview-close').focus({preventScroll:true});
}
function closePreview(restoreFocus=false){
  // AI_NOTE: 閉じた直後のフォーカス復帰で再表示しない。URLと一覧位置は変えない。
  clearTimeout(previewTimer);
  const trigger=previewTrigger;
  if(trigger)trigger.setAttribute('aria-expanded','false');
  preview.hidden=true;previewTrigger=null;previewPinned=false;
  if(restoreFocus&&trigger?.isConnected){restoringPreviewFocus=true;trigger.focus({preventScroll:true});restoringPreviewFocus=false;}
}
function schedulePreviewClose(){
  // AI_NOTE: 本文から小窓へ移動する隙間では消さず、読む間やキーボード操作中は保持する。
  clearTimeout(previewTimer);
  previewTimer=setTimeout(()=>{
    if(previewPinned||preview.contains(document.activeElement)||previewTrigger===document.activeElement)return;
    if(preview.matches(':hover')||previewTrigger?.matches(':hover'))return;
    closePreview();
  },220);
}
app.addEventListener('pointerover',e=>{const trigger=e.target.closest('.summary-trigger');if(trigger&&e.pointerType==='mouse'&&!trigger.contains(e.relatedTarget))openPreview(trigger);});
app.addEventListener('pointerout',e=>{if(e.target.closest('.summary-trigger'))schedulePreviewClose();});
app.addEventListener('focusin',e=>{const trigger=e.target.closest('.summary-trigger');if(trigger&&!restoringPreviewFocus)openPreview(trigger);});
app.addEventListener('focusout',schedulePreviewClose);
app.addEventListener('click',e=>{const trigger=e.target.closest('.summary-trigger');if(trigger)openPreview(trigger,true);});
preview.addEventListener('pointerenter',()=>clearTimeout(previewTimer));
preview.addEventListener('pointerleave',schedulePreviewClose);
preview.addEventListener('focusout',schedulePreviewClose);
document.querySelector('#preview-close').addEventListener('click',()=>closePreview(true));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!preview.hidden){e.preventDefault();closePreview(preview.contains(document.activeElement));}});
document.addEventListener('pointerdown',e=>{if(!preview.hidden&&!preview.contains(e.target)&&!previewTrigger?.contains(e.target))closePreview();});
window.addEventListener('resize',positionPreview);
window.addEventListener('scroll',e=>{if(!preview.hidden&&!preview.contains(e.target))closePreview();},true);

function renderRows(){
  // AI_NOTE: 小窓で全文を読めるよう、要点・結果・採否の本文を同じ操作に揃える。
  const found=items.filter(x=>(filter==='all'||(filter==='active'?['running','waiting'].includes(x.record.status):filter==='past'?['completed','interrupted'].includes(x.record.status):x.record.category===filter))&&JSON.stringify(x.record).toLowerCase().includes(search.toLowerCase()));
  const body=document.querySelector('#trial-rows');if(!body)return;
  body.innerHTML=found.map(x=>{const r=x.record;const stale=x.source_changes?.paths.length||x.source_changes?.error;return `<tr><td><div class="category">${labels[r.category]}</div><a class="trial-title" href="#experiment/${esc(r.id)}">${esc(r.title)}</a>${summaryButton(r.summary,'試行・ねらい')}${stale?'<span class="badge deferred">原本に更新・確認事項あり</span>':''}</td><td>${badge(r.status)}<div class="current">${esc(current(r))}</div></td><td>${badge(r.result.outcome)}${summaryButton(r.result.summary,'試行で分かったこと')}</td><td>${badge(r.decision.status)}${summaryButton(r.decision.reason,'手法の採否')}</td><td><span class="date">${date(x.saved_at).replace(' ','<br>')}</span><div class="muted">保存 · 第${x.revision}版</div></td></tr>`;}).join('')||'<tr><td colspan="5" class="empty">条件に一致する記録はありません。</td></tr>';
  document.querySelector('#visible-count').textContent=`${found.length}件`;
  const c=counts();document.querySelectorAll('.stat b').forEach((el,i)=>{el.textContent=[items.length,c.active,c.done,c.pending][i];});
}
function renderList(){
  // AI_NOTE: 絞り込みや手動更新で別の行を表示するときは小窓を閉じる。
  closePreview();
  const c=counts();document.title='探索の記録 — Shadowverse Deckmaker';
  app.innerHTML=`<div class="title-row"><div><div class="eyebrow">RESEARCH JOURNAL</div><h1>何を試し、何が分かったか</h1><p class="muted">探索手法の進捗と、判断の根拠を積み重ねる。</p></div><button id="refresh">最新の記録を表示</button></div><div class="stats"><div class="stat"><b>${items.length}</b><span>記録した試行</span></div><div class="stat"><b>${c.active}</b><span>進行中・待機</span></div><div class="stat"><b>${c.done}</b><span>実施完了</span></div><div class="stat"><b>${c.pending}</b><span>手法の採否は未判定</span></div></div><div class="toolbar"><div class="filters">${[['all','すべて'],['active','進行中'],['past','過去の試行'],['method','探索手法'],['infrastructure','基盤検証']].map(([key,name])=>`<button data-filter="${key}" aria-pressed="${filter===key}">${name}</button>`).join('')}</div><label class="screen-reader" for="search">試行を検索</label><input id="search" class="search" placeholder="手法・結果・課題を検索" value="${esc(search)}"><span id="visible-count" class="muted"></span></div><div class="table-wrap"><table class="trial-table"><thead><tr><th>試行・ねらい</th><th>状態 / 現在工程</th><th>試行で分かったこと</th><th>手法の採否</th><th>最終更新 · 日本時間</th></tr></thead><tbody id="trial-rows"></tbody></table></div><p class="footer-note">表示は保存された進捗です。実行プロセスの稼働確認ではありません。30秒ごとに保存版を確認します。</p><details><summary>記録の保存先</summary><p class="muted">台帳: ${esc(store)}<br>原本の参照先: ${esc(root)}<br>ブラウザを閉じても記録と訂正履歴は残ります。</p></details>`;
  renderRows();document.querySelector('#search').addEventListener('input',e=>{search=e.target.value;closePreview();renderRows();});
  document.querySelectorAll('[data-filter]').forEach(b=>b.addEventListener('click',()=>{filter=b.dataset.filter;renderList();}));
  document.querySelector('#refresh').addEventListener('click',async()=>{await load();renderList();notify('保存済みの最新記録を表示しました');});
}
const field=(title,text)=>`<div class="report-field"><h3>${title}</h3><div class="report-text">${esc(text)}</div></div>`;
function stagesTable(r,asOf=null){return `<div class="table-wrap"><table class="stage-table"><thead><tr><th>工程 / 状態</th><th>開始 · 日本時間</th><th>終了 · 日本時間</th><th>経過 / 目安</th><th>実施内容・残る作業</th></tr></thead><tbody>${r.stages.map(s=>{const time=elapsed(s,asOf),over=s.budget_minutes&&time.seconds>s.budget_minutes*60;return `<tr><td class="stage-title"><strong>${esc(s.title)}</strong><br>${badge(s.status)}</td><td><time class="date" title="${esc(s.started_at)}">${date(s.started_at).replace(' ','<br>')}</time></td><td><time class="date" title="${esc(s.ended_at)}">${date(s.ended_at).replace(' ','<br>')}</time></td><td class="elapsed ${over?'over':''}">${time.text}${s.budget_minutes?`<div class="muted">目安 ${s.budget_minutes}分</div>${over?'<div>目安を超過</div>':''}`:''}</td><td class="stage-note report-text">${esc(s.note)}</td></tr>`;}).join('')||'<tr><td colspan="5">工程はまだ記録されていません。</td></tr>'}</tbody></table></div>`;}
async function renderDetail(id,revision){
  const x=await api(`/api/experiments/${encodeURIComponent(id)}${revision?'?revision='+revision:''}`),r=x.record;
  const asOf=revision?x.saved_at:null;
  document.title=r.title+' — 探索の記録';
  app.innerHTML=`<a href="#" class="back">← 試行一覧</a><div class="title-row section-title"><div><div class="eyebrow">${labels[r.category]} · ${esc(r.id)}</div><h1>${esc(r.title)}</h1><div>${badge(r.status)}${badge(r.decision.status,'手法: '+labels[r.decision.status])}</div><p class="report-text">${esc(r.summary)}</p><p class="muted">最終保存 ${date(x.saved_at)}（日本時間） · 第${x.revision}版 · 記録者 ${esc(x.actor)}</p></div><div class="actions"><a class="button primary" href="#edit/${esc(r.id)}">進捗・報告を更新</a><button id="detail-refresh">最新を表示</button></div></div>${revision?'<div class="callout revision-banner">過去の保存版を表示しています。編集は最新版から行います。</div>':''}${x.source_changes.error?`<div class="callout">原本の確認ができません: ${esc(x.source_changes.error)}。保存済み資料は閲覧できます。</div>`:x.source_changes.paths.length?`<div class="callout"><strong>原本に未取込の変更が ${x.source_changes.paths.length}件あります。</strong> この報告は保存時点の内容です。更新画面で報告を確認して保存すると、新しい根拠資料も保存されます。<details><summary>変更された資料</summary>${x.source_changes.paths.map(esc).join('<br>')}</details></div>`:''}<div class="detail-grid"><section class="panel"><h2>試行の結果 ${badge(r.result.outcome)}</h2><div class="report-text">${esc(r.result.summary)}</div></section><section class="panel"><h2>手法の採否 ${badge(r.decision.status)}</h2><div class="report-text">${esc(r.decision.reason)}</div></section></div><section class="panel"><h2>現在の工程</h2><p>${esc(current(r))}</p><p class="muted">試行の開始: ${date(r.started_at)} / 終了: ${date(r.ended_at)}<br>試行全体の経過: ${elapsed(r,asOf).text}（開始から終了・${revision?'保存時点':'現在'}まで。待機を含む）</p></section><h2 class="section-title">工程と時間</h2>${stagesTable(r,asOf)}<p class="muted">工程の時間はそれぞれの開始〜終了です。並行工程は合算しません。未記録の日時は保存日時から推定していません。待機に移る場合は作業区間を閉じ、別の工程として記録します。</p><div class="detail-grid"><section class="panel">${field('手法のねらい',r.method)}${field('実際に行った手順',r.procedure)}</section><section class="panel">${field('固定した入力・対象範囲',r.inputs)}${field('判断基準',r.criteria)}</section></div><section class="panel">${field('残る問題・検証の限界',r.result.limitations)}</section><section class="panel"><h2>根拠資料 <span class="muted">${x.evidence.length}件 · この版の保存原文</span></h2><label for="source-search">資料名で絞り込む</label><input id="source-search" class="source-search" placeholder="README、protocol、round-4 など"><ul class="evidence-list">${x.evidence.map(e=>`<li data-path="${esc(e.path)}"><a href="/source?id=${encodeURIComponent(r.id)}&revision=${x.revision}&path=${encodeURIComponent(e.path)}">${esc(e.path)}</a><small>SHA-256 ${esc(e.sha256)}</small></li>`).join('')||'<li>資料未登録</li>'}</ul></section><section class="panel"><h2>保存・訂正の履歴</h2><p class="muted">保存時刻は報告を書き込んだ時刻です。工程の実施日時とは別に記録しています。</p><ol class="history">${x.history.map(h=>`<li><a href="#experiment/${esc(r.id)}/${h.revision}">第${h.revision}版</a> · ${date(h.saved_at)}（日本時間） · ${esc(h.actor)}<div class="report-text">${esc(h.reason)}</div></li>`).join('')}</ol></section>`;
  document.querySelector('#source-search').addEventListener('input',e=>{document.querySelectorAll('[data-path]').forEach(li=>li.hidden=!li.dataset.path.toLowerCase().includes(e.target.value.toLowerCase()));});
  document.querySelector('#detail-refresh').addEventListener('click',()=>{location.hash=`experiment/${id}`;renderDetail(id);});
}
const options=(values,value)=>values.map(v=>`<option value="${v}" ${v===value?'selected':''}>${labels[v]}</option>`).join('');
const input=(label,name,value,large=false)=>`<label>${label}${large?`<textarea name="${name}">${esc(value)}</textarea>`:`<input name="${name}" value="${esc(value)}" required>`}</label>`;
const select=(label,name,value,values)=>`<label>${label}<select name="${name}">${options(values,value)}</select></label>`;
const toLocal=value=>value?new Date(new Date(value).getTime()+9*3600000).toISOString().slice(0,23):'';
function timeInput(label,name,value){const local=toLocal(value);return `<label>${label}（日本時間・空欄は未記録）<span class="time-entry"><input type="datetime-local" step="0.001" name="${name}" value="${local}" data-original="${esc(value||'')}" data-initial="${local}"><button type="button" data-now="${name}">今の日時</button></span></label>`;}
function editStages(stages){return stages.map((s,i)=>`<div class="edit-stage"><h3>工程 ${i+1} <button type="button" data-remove-stage="${i}">この版から外す</button></h3><div class="form-grid">${input('工程ID',`stage-${i}-id`,s.id)}${input('工程名',`stage-${i}-title`,s.title)}${select('状態',`stage-${i}-status`,s.status,['planned','running','waiting','completed','interrupted'])}<label>目安時間（分）<input name="stage-${i}-budget_minutes" type="number" min="0.01" step="any" value="${s.budget_minutes??''}"></label>${timeInput('開始',`stage-${i}-started_at`,s.started_at)}${timeInput('終了',`stage-${i}-ended_at`,s.ended_at)}<div class="wide">${input('内容・残る作業・時刻の根拠',`stage-${i}-note`,s.note,true)}</div></div></div>`).join('');}
function readTime(form,name){const el=form.elements[name];return el.value===el.dataset.initial?(el.dataset.original||null):el.value?new Date(el.value+'+09:00').toISOString():null;}
function readForm(){const f=document.querySelector('#record-form'),r=structuredClone(editing.record);for(const key of ['title','category','status','summary','method','procedure','inputs','criteria'])r[key]=f.elements[key].value;r.id=f.elements.id.value;r.started_at=readTime(f,'started_at');r.ended_at=readTime(f,'ended_at');r.result={outcome:f.elements.outcome.value,summary:f.elements.result_summary.value,limitations:f.elements.limitations.value};r.decision={status:f.elements.decision_status.value,reason:f.elements.decision_reason.value};r.evidence_paths=f.elements.evidence_paths.value.split('\n').map(s=>s.trim()).filter(Boolean);r.stages=editing.record.stages.map((s,i)=>({id:f.elements[`stage-${i}-id`].value,title:f.elements[`stage-${i}-title`].value,status:f.elements[`stage-${i}-status`].value,started_at:readTime(f,`stage-${i}-started_at`),ended_at:readTime(f,`stage-${i}-ended_at`),budget_minutes:f.elements[`stage-${i}-budget_minutes`].value?Number(f.elements[`stage-${i}-budget_minutes`].value):null,note:f.elements[`stage-${i}-note`].value}));return r;}
function renderForm(){const r=editing.record;
  app.innerHTML=`<a href="${editing.revision?'#experiment/'+esc(r.id):'#'}">← 保存せずに戻る</a><h1 class="section-title">${editing.revision?'進捗・報告を更新':'新しい試行を記録'}</h1><p class="muted">${editing.revision?`第${editing.revision}版から編集。保存すると新しい版が追加されます。`:'これから行う試行は「未着手」で登録できます。'} 実施日時は分かるものだけ記入してください。</p><form id="record-form"><section class="panel"><div class="form-grid">${input('記録ID（英小文字・数字・ハイフン）','id',r.id)}${input('試行の名前','title',r.title)}${select('分類','category',r.category,['method','infrastructure'])}${select('試行の状態','status',r.status,['planned','running','waiting','completed','interrupted'])}<div class="wide">${input('一覧に載せる要点','summary',r.summary,true)}</div>${timeInput('試行の開始','started_at',r.started_at)}${timeInput('試行の終了','ended_at',r.ended_at)}</div></section><section class="panel"><h2>工程の進捗</h2><p class="muted">待機・再開は別の工程区間に分けます。前の区間を完了・中断として閉じると、作業時間と待機時間を見分けられます。外した工程も過去版には残ります。</p><div id="stage-editor">${editStages(r.stages)}</div><button type="button" id="add-stage">工程を追加</button></section><section class="panel"><h2>検証の内容</h2><div class="form-grid">${input('手法のねらい','method',r.method,true)}${input('実際に行った手順','procedure',r.procedure,true)}${input('固定した入力・対象範囲','inputs',r.inputs,true)}${input('判断基準','criteria',r.criteria,true)}</div></section><section class="panel"><h2>結果と採否</h2><div class="form-grid">${select('試行結果','outcome',r.result.outcome,['unassessed','mixed','pass','fail'])}${select('手法の採否','decision_status',r.decision.status,['unassessed','adopted','rejected','deferred'])}${input('実施して分かったこと','result_summary',r.result.summary,true)}${input('採用・却下・保留・未判定の理由','decision_reason',r.decision.reason,true)}<div class="wide">${input('残る問題・検証の限界','limitations',r.result.limitations,true)}</div></div></section><section class="panel"><h2>根拠資料</h2><p class="muted">${esc(root)} 内の evals/・docs/・tests/fixtures/ 配下の相対パスを1行ずつ記入。ディレクトリは配下の資料も保存します。保存時点の原文を残し、以前の版の原文は保持します。</p>${input('資料ファイル・ディレクトリ','evidence_paths',r.evidence_paths.join('\n'),true)}</section><p id="form-error" role="alert" class="form-error"></p><div class="save-row">${input('記録者','actor',editing.actor||'')}${input('更新・訂正の理由','reason',editing.reason||'')}<button type="submit" class="primary" id="save">記録を保存</button></div></form>`;
  document.querySelectorAll('input[type=datetime-local]').forEach(el=>{el.dataset.initial=el.value;});
  if(editing.revision)document.querySelector('[name=id]').readOnly=true;
  document.querySelectorAll('[data-now]').forEach(b=>b.addEventListener('click',()=>{document.querySelector(`[name="${b.dataset.now}"]`).value=toLocal(new Date().toISOString());}));
  const keep=()=>{editing.actor=document.querySelector('[name=actor]').value;editing.reason=document.querySelector('[name=reason]').value;editing.record=readForm();};
  document.querySelector('#add-stage').addEventListener('click',()=>{keep();editing.record.stages.push({id:'',title:'',status:'planned',started_at:null,ended_at:null,note:'未記録',budget_minutes:null});const y=window.scrollY;renderForm();window.scrollTo(0,y);});
  document.querySelectorAll('[data-remove-stage]').forEach(b=>b.addEventListener('click',()=>{keep();editing.record.stages.splice(Number(b.dataset.removeStage),1);const y=window.scrollY;renderForm();window.scrollTo(0,y);}));
  document.querySelector('#record-form').addEventListener('submit',async e=>{e.preventDefault();const button=document.querySelector('#save');button.disabled=true;document.querySelector('#form-error').textContent='';try{const r=readForm();const x=await api('/api/experiments',{method:'POST',headers:{'Content-Type':'application/json','X-Journal-Token':token},body:JSON.stringify({record:r,expected_revision:editing.revision,actor:e.target.elements.actor.value,reason:e.target.elements.reason.value})});editing=null;await load();location.hash=`experiment/${x.id}`;notify(`第${x.revision}版を保存しました`);}catch(err){document.querySelector('#form-error').textContent=err.message;button.disabled=false;}});
}
async function route(){
  // AI_NOTE: 読んでいる小窓と焦点を自動更新で壊さず、画面遷移時には閉じる。
  closePreview();clearInterval(refreshTimer);const [kind,id,rev]=location.hash.slice(1).split('/');try{if(kind==='edit'){editing=await api('/api/experiments/'+encodeURIComponent(id));editing.actor='';renderForm();}else if(kind==='new'){editing={revision:0,record:{id:'',title:'',category:'method',status:'planned',summary:'',method:'',procedure:'',inputs:'',criteria:'',result:{outcome:'unassessed',summary:'未判定',limitations:'未記録'},decision:{status:'unassessed',reason:'未判定'},started_at:null,ended_at:null,stages:[],evidence_paths:[]}};renderForm();}else{editing=null;await load();if(kind==='experiment')await renderDetail(id,rev);else{renderList();window.scrollTo(0,listScroll);}refreshTimer=setInterval(async()=>{try{await load();if(!location.hash){if(preview.hidden&&!document.activeElement?.closest('.summary-trigger'))renderRows();}else if(location.hash.startsWith('#experiment/')){const latest=items.find(x=>x.id===id);const link=document.querySelector('#detail-refresh');if(latest&&link)link.textContent=`最新を表示（第${latest.revision}版）`;}}catch(err){notify('更新確認に失敗しました: '+err.message);}},30000);}}catch(err){app.innerHTML=`<div class="callout error"><h1>記録を表示できません</h1><p>${esc(err.message)}</p><a href="#">一覧に戻る</a></div>`;}}
window.addEventListener('hashchange',()=>{route();if(location.hash)window.scrollTo(0,0);});
window.addEventListener('scroll',()=>{if(!location.hash)listScroll=window.scrollY;});
window.addEventListener('beforeunload',e=>{if(editing){e.preventDefault();e.returnValue='';}});
load().then(route).catch(err=>app.innerHTML=`<p class="callout error">${esc(err.message)}</p>`);
