from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from collections import Counter
import hashlib, html, json, re, threading, time, urllib.error
from urllib.parse import urlparse
from svdeck import meta

ROOT=Path('/Users/miyauchitsubasa/Desktop/github/shadowverse-deckmaker')
OUT=Path('/tmp/live-query-article-diagnosis')
protocol=json.loads((ROOT/'evals/discovery/live-query-discovery-01/protocol.json').read_text())
db=ROOT/'data/cards.db'
started=datetime.now(timezone.utc).isoformat(); monotonic=time.monotonic()
db_before=hashlib.sha256(db.read_bytes()).hexdigest()
local=threading.local()
urlopen=meta.urllib.request.urlopen
get_html=meta._get_html
parse8=meta.parse_game8_decks
parsewith=meta.parse_gamewith_deck
recipe=meta._recipe_cards


def http(request, *args, **kwargs):
    kwargs['timeout']=20
    try:
        response=urlopen(request,*args,**kwargs)
        local.record['http']={'status':response.status,'final_url':response.geturl(),'content_type':response.headers.get('Content-Type')}
        return response
    except urllib.error.HTTPError as exc:
        local.record['http']={'status':exc.code,'final_url':exc.geturl()}
        raise


def fetch(url):
    local.record['phase']='HTTP取得・UTF-8復号'
    body=get_html(url)
    path=OUT/(urlparse(url).hostname+'-'+urlparse(url).path.rstrip('/').split('/')[-1]+'.html')
    path.write_text(body,encoding='utf-8')
    local.record['html']={'path':str(path),'utf8_bytes':len(body.encode()),'sha256':hashlib.sha256(body.encode()).hexdigest()}
    start=re.search(r'<h2\b[^>]*\bid="hl_1"[^>]*>',body)
    segment=re.split(r'<h2\b',body[start.end():],maxsplit=1)[0] if start else ''
    headings=list(re.finditer(r'<h3\b[^>]*\bid="([^"]+)"[^>]*>(.*?)</h3>',segment,re.S))
    header=r'<th\b[^>]*\bcolspan="5"[^>]*>\s*デッキレシピ\s*</th>'
    links=[x for x in re.findall(r'href="([^"]+)"',segment) if urlparse(html.unescape(x)).hostname=='shadowverse-wb.com' and urlparse(html.unescape(x)).path.endswith('/deck/detail/')]
    local.record['structure']={'h2_ids':re.findall(r'<h2\b[^>]*\bid="([^"]+)"',body),
       'main_hl1_found':start is not None,'main_segment_characters':len(segment),'h3_with_id_count':len(headings),
       'h3_any_count':len(re.findall(r'<h3\b',segment)),'recipe_header_count':len(re.findall(header,segment)),
       'copy_link_count':len(set(links)),
       'recipe_headers_before_first_h3':len(re.findall(header,segment[:headings[0].start()] if headings else segment)),
       'heading_blocks_with_recipe_header':sum(bool(re.search(header,segment[h.end():headings[i+1].start() if i+1<len(headings) else len(segment)])) for i,h in enumerate(headings))}
    return body


def parser8(body):
    local.record['phase']='parse_game8_decks: hl_1内のh3ごとのレシピ分離'
    result=parse8(body)
    local.record['parsed_recipe_count']=len(result)
    local.record['recipe_structures']=[{'display_entries':len(d.cards),'display_total':sum(n for _,n in d.cards),'has_copy_url':bool(d.copy_url),'anchor':d.anchor} for d in result]
    return result


def parserwith(body):
    local.record['phase']='parse_gamewith_deck'
    result=parsewith(body)
    local.record['parsed_recipe_count']=1
    local.record['recipe_structures']=[{'display_entries':len(result.cards),'display_total':sum(n for _,n in result.cards),'has_copy_url':bool(result.copy_url)}]
    return result


def resolve(*args,**kwargs):
    local.record['phase']='_recipe_cards: 固定DBとの照合・40枚検査'
    value=recipe(*args,**kwargs)
    return value

meta.urllib.request.urlopen=http
meta._get_html=fetch
meta.parse_game8_decks=parser8
meta.parse_gamewith_deck=parserwith
meta._recipe_cards=resolve


def inspect(url):
    local.record={'url':url,'started_at':datetime.now(timezone.utc).isoformat(),'phase':'準備'}
    tick=time.monotonic()
    try:
        result=meta.article_sources(db,url,'rotation',with_text=True)
        local.record.update(status='取得・解析・固定DB照合成功',source_count=len(result['sources']),source_kinds=dict(Counter(s['kind'] for s in result['sources'])))
    except Exception as exc:
        phase=local.record['phase']
        status='取得失敗' if phase.startswith('HTTP') else '解析失敗' if phase.startswith('parse_') else '照合・資料化失敗'
        local.record.update(status=status,error_type=type(exc).__name__,error=str(exc))
    local.record.update(ended_at=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-tick)
    (OUT/(urlparse(url).hostname+'-'+urlparse(url).path.rstrip('/').split('/')[-1]+'.json')).write_text(json.dumps(local.record,ensure_ascii=False,indent=2))
    return dict(local.record)

results=[]
with ThreadPoolExecutor(max_workers=4) as pool:
    futures={pool.submit(inspect,url):url for url in protocol['articles']}
    for future in as_completed(futures):
        value=future.result();results.append(value)
        print(json.dumps({'url':value['url'],'status':value['status'],'phase':value['phase'],'http':value.get('http'),'structure':value.get('structure')},ensure_ascii=False),flush=True)
results.sort(key=lambda v:protocol['articles'].index(v['url']))
report={'started_at':started,'ended_at':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-monotonic,'total':len(protocol['articles']),'classified':len(results),'counts':dict(Counter(v['status'] for v in results)),'articles':results,'db_sha256_before':db_before,'db_sha256_after':hashlib.sha256(db.read_bytes()).hexdigest(),'source_exists':Path(protocol['source']).exists(),'method':'既存article_sources(with_text=True)を全8URLに各1回実行。取得は既存_get_html、解析・40枚照合も既存関数。メモリ上の計測ラッパーでHTTP情報とHTMLを保存し、接続timeoutだけ20秒を指定。4並行。コードファイル・DB・探索入力は未編集。'}
Path('/tmp/live-query-article-diagnosis.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'done':True,'counts':report['counts'],'elapsed_seconds':report['elapsed_seconds'],'db_unchanged':report['db_sha256_before']==report['db_sha256_after']},ensure_ascii=False))
