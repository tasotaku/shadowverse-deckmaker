from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

root = Path('/tmp/sv-same-slot-alternative-01-worktree')
evidence = Path('/tmp/same-slot-alternative-prototype-evidence')
common = Path('/Users/miyauchitsubasa/Desktop/github/shadowverse-deckmaker/data/discovery/same-slot-alternative-01-input')
record_path = Path('/tmp/same-slot-alternative-prototype.json')
started = datetime.now(timezone.utc).isoformat()

def manifest(folder):
    return {str(path.relative_to(folder)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(folder.rglob('*')) if path.is_file()}

def difference(a, b, prefix=''):
    if type(a) is not type(b):
        return [prefix]
    if isinstance(a, dict):
        return [p for k in a.keys() | b.keys() for p in
                ([prefix+'/'+k] if k not in a or k not in b else difference(a[k], b[k], prefix+'/'+k))]
    if isinstance(a, list):
        if len(a) != len(b): return [prefix]
        return [p for i, (x, y) in enumerate(zip(a, b)) for p in difference(x, y, prefix+'/'+str(i))]
    return [] if a == b else [prefix]

before = manifest(common)
base_src = evidence/'base-src'
shutil.copytree(root/'src', base_src)
base_code = subprocess.check_output(['git', 'show', '251a5c66f28a2257d1aeaa8d916c9738178f4b25:src/svdeck/discovery.py'], cwd=root)
(base_src/'svdeck/discovery.py').write_bytes(base_code)
variants = {}
for name, source in [('a', base_src), ('b', root/'src')]:
    session = evidence/(name+'-session')
    shutil.copytree(common, session)
    variants[name] = (session, dict(os.environ, PYTHONPATH=str(source)))

calls = []
def public(name, label, arguments):
    session, env = variants[name]
    command = [sys.executable, '-m', 'svdeck.discovery', *arguments]
    result = subprocess.run(command, cwd=root, env=env, text=True, capture_output=True)
    path = evidence/f'{name}-{label}.json'
    path.write_text(result.stdout)
    error_path = evidence/f'{name}-{label}.stderr'
    error_path.write_text(result.stderr)
    calls.append({'variant': name, 'command': command, 'exit_code': result.returncode,
                  'output': str(path), 'stderr': str(error_path)})
    if result.returncode:
        raise RuntimeError(result.stderr)
    return json.loads(result.stdout)

checks = []
try:
    first_a = public('a', 'develop-revision-1', ['packet', str(variants['a'][0]), '--revision', '1'])
    source_hash = first_a['data']['sources'][0]['source_hash']
    cases = [('develop-revision-0', ['--revision','0'], True),
             ('develop-revision-1', ['--revision','1'], True),
             ('review-revision-1', ['--revision','1','--stage','review'], False),
             ('finish-revision-0', ['--revision','0','--finish-from-source',source_hash], False),
             ('finish-revision-1', ['--revision','1','--finish-from-source',source_hash], False)]
    for label, args, changes in cases:
        packets = {name: public(name,label,['packet',str(session),*args]) for name,(session,_) in variants.items()}
        paths = sorted(difference(packets['a'],packets['b']))
        expected = ['/data/instruction', '/sha256'] if changes else []
        checks.append({'case':label,'changed_paths':paths,'expected_paths':expected,'passed': paths == expected,
                       'a_sha256':packets['a']['sha256'],'b_sha256':packets['b']['sha256']})
        if changes:
            old, new = (packets[name]['data']['instruction'] for name in ('a','b'))
            checks[-1]['preserves_existing_instruction'] = new.startswith(old)
            checks[-1]['added_instruction'] = new[len(old):]
            checks[-1]['passed'] &= new.startswith(old)
        if label == 'develop-revision-1':
            for name,(session,_) in variants.items():
                summary = public(name,'develop-summary',['packet',str(session),'--revision','1','--summary'])
                read = public(name,'instruction-read',['read',str(session),packets[name]['sha256'],'instruction','--limit','100'])
                checks.append({'case':name+'-public-summary-and-read','passed':
                               summary['instruction'] == packets[name]['data']['instruction'] == ''.join(read['content'])
                               and read['next_offset'] is None})
    retained = before == manifest(common)
    passed = all(check['passed'] for check in checks) and retained
    result = {'started_at':started,'ended_at':datetime.now(timezone.utc).isoformat(),
              'common_input':str(common),'common_input_files':len(before),'common_input_unchanged':retained,
              'initial_counts':{'revisions':len(list(common.glob('revision-*.json'))),'reviews':len(list(common.glob('review-*.json'))),
                                'sources':len(first_a['data']['sources'])},
              'checks':checks,'commands':calls,'passed':passed}
except Exception as exc:
    result = {'started_at':started,'ended_at':datetime.now(timezone.utc).isoformat(),'checks':checks,'commands':calls,'passed':False,'error':repr(exc)}
result_path = evidence/'public-packet-scope.json'
result_path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
record = json.loads(record_path.read_text())
record['public_packet_check'] = {'path':str(result_path),**result}
if not result['passed']: record['failures'].append({'phase':'public_packet_check',**result})
record_path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k != 'commands'},ensure_ascii=False,indent=2))
raise SystemExit(0 if result['passed'] else 1)
